/*
 * testhandler.h 
 */

void            init_testhandler(void);
Netsnmp_Node_Handler my_test_handler;
Netsnmp_Node_Handler my_test_table_handler;
Netsnmp_Node_Handler my_data_table_handler;
Netsnmp_Node_Handler my_test_instance_handler;
