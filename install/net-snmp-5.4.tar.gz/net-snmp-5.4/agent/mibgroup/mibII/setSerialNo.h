#ifndef SETSERIALNO_H
#define SETSERIALNO_H

Netsnmp_Node_Handler netsnmp_setserialno_handler;
void            init_setSerialNo(void);

#endif                          /* SETSERIALNO_H */
