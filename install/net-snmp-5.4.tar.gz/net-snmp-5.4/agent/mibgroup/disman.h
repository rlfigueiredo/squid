/*
 * Wrapper for the full DisMan implementation
 */
config_require(disman/event-mib)
config_require(disman/expression-mib)
config_require(disman/schedule)
/* config_require(disman/nslookup-mib)   */
/* config_require(disman/ping-mib)       */
/* config_require(disman/traceroute-mib) */
