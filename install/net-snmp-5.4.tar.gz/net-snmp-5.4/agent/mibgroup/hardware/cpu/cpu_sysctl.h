config_require(hardware/cpu/cpu)
void init_cpu_sysctl(void);
